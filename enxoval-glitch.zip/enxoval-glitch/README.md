# 🏠 Enxoval da Casa Nova

Lista colaborativa em tempo real — qualquer pessoa abre o link e marca os itens, e todo mundo vê na hora.

## Como subir no Glitch

1. Acesse https://glitch.com e crie uma conta gratuita (só e-mail)
2. Clique em **"New Project" → "Import from GitHub"**
   - Ou: clique em **"New Project" → "glitch-hello-node"** e substitua os arquivos
3. Apague os arquivos existentes e envie os desta pasta:
   - `server.js`
   - `package.json`
   - `public/index.html`
4. O Glitch instala as dependências automaticamente
5. Clique em **"Share"** e copie o link público (ex: `seu-projeto.glitch.me`)
6. Mande o link no WhatsApp ✅

## Como funciona

- Cada toque em um item sincroniza para todos os usuários em tempo real (via Socket.io)
- Os dados ficam salvos em `data.json` no servidor
- Sem login, sem senha para quem acessa

## Dependências

- express
- socket.io
