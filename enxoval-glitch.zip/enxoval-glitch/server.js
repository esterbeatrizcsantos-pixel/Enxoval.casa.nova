const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const fs = require("fs");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const DB_FILE = path.join(__dirname, "data.json");

function loadData() {
  try {
    if (fs.existsSync(DB_FILE)) {
      return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
    }
  } catch (e) {}
  return {};
}

function saveData(data) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data), "utf8");
  } catch (e) {}
}

let checked = loadData();

app.use(express.static(path.join(__dirname, "public")));

io.on("connection", (socket) => {
  socket.emit("init", checked);

  socket.on("toggle", (idx) => {
    checked[idx] = !checked[idx];
    saveData(checked);
    io.emit("update", { idx, value: checked[idx] });
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log("Servidor rodando na porta " + PORT);
});
